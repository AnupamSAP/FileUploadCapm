sap.ui.define(
    [
        "sap/ui/core/mvc/Controller"
    ],
    function(BaseController) {
      "use strict";
  
      return BaseController.extend("nmpspc.attachfileui.controller.App", {
        onInit: function() {
        }
      });
    }
  );
  